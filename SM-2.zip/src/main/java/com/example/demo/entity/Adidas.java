package com.example.demo.entity;

import lombok.Data;

@Data
public class Adidas {
    private int shoeNum;
    private String shoeName;
    private int shoePrice;
    private String releaseYear;
    private String company;
    private int shoeRate;
}
