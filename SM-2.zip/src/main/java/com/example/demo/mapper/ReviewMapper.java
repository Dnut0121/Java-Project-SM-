package com.example.demo.mapper;

import com.example.demo.entity.Review;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ReviewMapper {

    @Select("SELECT * FROM reviews WHERE shoe_num = #{shoeNum} ORDER BY review_date DESC")
    List<Review> getReviewsByShoeNum(int shoeNum);

    @Insert("INSERT INTO reviews (shoe_num, username, review_text, review_date) VALUES (#{shoeNum}, #{username}, #{reviewText}, #{reviewDate})")
    void insertReview(Review review);
}
